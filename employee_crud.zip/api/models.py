from django.db import models

# Create your models here.

class EmployeeModel(models.Model):
  firstname = models.CharField(max_length=255)
  email = models.CharField(max_length=50, unique=True)
  photo = models.CharField(null=True, max_length=255)

  def __str__(self):
    return self.id