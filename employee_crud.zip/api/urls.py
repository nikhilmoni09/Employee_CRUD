from django.urls import path

from . import views


urlpatterns = [
    path("", views.index, name="index"),
    path("employee", views.employee, name="employee"),
    path("delete_employee", views.delete_employee, name="delete_employee"),
    path("update_employee", views.update_employee, name="update_employee")
]