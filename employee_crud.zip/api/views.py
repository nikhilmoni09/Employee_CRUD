from django.http import HttpResponse, JsonResponse
from .models import EmployeeModel
from django.views.decorators.csrf import csrf_exempt


def index(request):
    return HttpResponse("Hello, world. You're at the polls index.")

@csrf_exempt
def employee(request):
    try:
        # get all records using get request
        if request.method == 'GET':
            all_entries = list(EmployeeModel.objects.values(
                    'id', 'firstname', 'email', 'photo'))
            response = {
            'data': all_entries,
            'message': 'Success',
            'status': True
             }
            return JsonResponse(response)
        # create records using POST request
        if request.method == 'POST':
            firstname = request.POST.get('firstname', None)
            email = request.POST.get('email', None)
            photo = request.POST.get('photo', None)
            if not firstname:
                response = {
                    'message': 'first_name_required',
                    'status': False}
                return JsonResponse(response)
            if not email:
                response = {
                    'message': 'email_required',
                    'status': False}
                return JsonResponse(response)

            queryset = EmployeeModel.objects.create(
                    firstname = firstname, 
                    email = email, 
                    photo = photo)  
            queryset.save()
            response = {
                'message': 'Success',
                'status': True
            }
            return JsonResponse(response)
        else:
            response = {
                'message': 'invalid_request',
                'status': False
            }
            return JsonResponse(response)        
        response = {
            'message': 'Success',
            'status': True
        }
        return JsonResponse(response)
    except Exception as error:
        response = {
            'error_message': str(error),
            'status': False
        }
        return JsonResponse(response)


@csrf_exempt
def delete_employee(request):
    try:        
        # delete records using POST request
        if request.method == 'POST':
            id = request.POST.get('id', None)
            is_admin = request.POST.get('is_admin', False)
            if not id:
                response = {
                    'message': 'id_required',
                    'status': False}
                return JsonResponse(response)
            if is_admin:
                delete_status = EmployeeModel.objects.filter(id=id).delete()
            else:
                response = {
                'id': id,
                'message': 'no_permission',
                'status': False
                }
                return JsonResponse(response)
            if int(delete_status[0]) != 0:
                response = {
                'id': id,
                'message': 'Delete Success',
                'status': True
                }
                return JsonResponse(response)
            else:
                response = {
                'id': id,
                'message': 'invalid_id',
                'status': False
                }
                return JsonResponse(response)
        else:
            response = {
                'message': 'invalid_request',
                'status': False
            }
            return JsonResponse(response)
        response = {
            'message': 'Success',
            'status': True
        }
        return JsonResponse(response)
    except Exception as error:
        response = {
            'error_message': str(error),
            'status': False
        }
        return JsonResponse(response)  


@csrf_exempt
def update_employee(request):
    try:
        # update records using POST request
        if request.method == 'POST':
            emp_id = request.POST.get('id', None)
            firstname = request.POST.get('firstname', None)
            email = request.POST.get('email', None)
            photo = request.POST.get('photo', None)
            is_admin = request.POST.get('is_admin', False)
            if not id:
                response = {
                    'message': 'id_required',
                    'status': False}
                return JsonResponse(response)
            if not firstname:
                response = {
                    'message': 'first_name_required',
                    'status': False}
                return JsonResponse(response)
            if not email:
                response = {
                    'message': 'email_required',
                    'status': False}
                return JsonResponse(response)
            if is_admin:
                update_status = EmployeeModel.objects.filter(id=emp_id).update(
                        firstname=firstname, email=email, photo=photo)
                print('update_status', update_status)
            else:
                response = {
                'message': 'no_permission',
                'status': False
                }
                return JsonResponse(response)
            if int(update_status) != 0:
                response = {
                'message': 'Update Success',
                'status': True
                }
                return JsonResponse(response)
            else:
                response = {
                'message': 'invalid_id',
                'status': False
                }
                return JsonResponse(response)
        else:
            response = {
                'message': 'invalid_request',
                'status': False
            }
            return JsonResponse(response)        
        response = {
            'message': 'Success',
            'status': True
        }
        return JsonResponse(response)
    except Exception as error:
        response = {
            'error_message': str(error),
            'status': False
        }
        return JsonResponse(response)
